<script>
import comment from './components/Comment/index.vue'
export default {
  components: {
    comment,
  },
}
</script>

<template>
  <div>
    <comment></comment>
  </div>
</template>

