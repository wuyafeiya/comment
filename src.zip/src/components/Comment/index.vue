<template>
  <div class="bg" style="display: flex; flex-direction: column">
    <van-swipe class="my-swipe" :autoplay="30000" indicator-color="white" vertical style="height: 100%;" :show-indicators="false">
      <van-swipe-item v-for="(item,index) in 3" :key="index">
        <div @click="PopupshowClick" class="options">
          <div v-for="(item, index) in ['links', 'comment', 'start', 'share']" :key="index" style="display: flex; flex-direction: column; color: #fff">
            <svg-icon :icon-class="item" style="width: 32px; height: 32px" />
            <span style="text-align: center; margin-top: 5px">123</span>
          </div>
        </div>
        <van-popup v-model="Popupshow" position="bottom" class="popup" round get-container=".bg">
          <div class="comment">
            <div class="commentnum" style="position: sticky">{{ comments.total }} 条评论</div>
            <CommentList :commentList="comments.comments"></CommentList>
            <div class="send"><input type="text" placeholder="说点什么吧..." enterkeyhint="send" /></div>
          </div>
        </van-popup>
        <!-- <video controls autoplay src="./video.mp4" style="width: 100%; height: 100%;"></video> -->
      </van-swipe-item>
    </van-swipe>
  </div>
</template>
<script>
import convertToTreeData from "../utils/index"
import CommentList from "./comment-list.vue"
import { getComment } from "@/api/user"
import { addComment } from "@/api/user"
export default {
  name: "CommentS",
  components: {
    CommentList,
  },
  data() {
    return {
      comments: {},
      id: 0,
      show: false,
      Popupshow: false,
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    PopupshowClick() {
      this.Popupshow = !this.Popupshow
    },
    async init() {
      const form = new FormData()
      const obj = {
        site_name: "artalk",
        page_key: "/",
        limit: 10,
        offset: 0,
        flat_mode: true,
      }
      Object.keys(obj).forEach((item) => {
        form.append(item, obj[item])
      })
      const {
        data: { data },
      } = await getComment(form)
      this.comments = { comments: convertToTreeData(data.comments), total: data.total }
    },
    async send() {
      const form = new FormData()
      const params = {
        name: "biubiu",
        email: "wuyafeiya@gmail.com",
        link: "",
        content: this.content,
        rid: this.id,
        page_key: "/",
        site_name: "artalk",
        page_title: "Vite App",
        ua: "ios",
      }
      Object.keys(params).forEach((item) => {
        form.append(item, params[item])
      })
      await addComment(form)
    },
  },
}
</script>
<style lang="scss" scoped>
body {
  background: #f4f4f4;
}

.bg {
  width: 100%;
  height: 100vh;
  // overflow: hidden;
  position: relative;
  background: red;

  .popup {
    width: 100%;
    height: 618px;
    display: flex;
    place-content: center;
  }
  .options {
    position: absolute;
    bottom: 60px;
    right: 38px;
    z-index: 1;
    display: flex;
    flex-direction: column;
    gap: 20px;
    // margin-right: -38px;
  }
  .start {
    position: absolute;
    padding-right: 38px;
    right: 0;
  }
}

.comment {
  width: 100%;
  height: 100%;
  overflow: hidden;
  overflow-y: auto;
  background: #fff;
  padding: 0 24px;
  .commentnum {
    text-align: center;
    padding: 10px 0;
    position: sticky;
    top: 0;
    background: #fff;
    z-index: 1;
  }
  .send {
    height: 67px;
    position: sticky;
    bottom: 0;
    background: #fff;
    z-index: 1;
    display: flex;
    input {
      box-sizing: border-box;
      font-size: 12px;
      border: none;
      width: 100%;
      height: 35px;
      border-radius: 35px;
      margin: auto;
      background-color: #f2f2f2;
      padding: 0 10px;
    }
  }
}

::-webkit-scrollbar {
  width: 0.5em;
  background-color: transparent;
  /* 可选，如果想要透明背景 */
}

::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 0, 0);
  /* 隐藏滚动条的轨道 */
}
</style>
